using System;

class MathUtil
{
    private int number1;
    private int number2;

    public MathUtil(int number1, int number2)
    {
        this.number1 = number1;
        this.number2 = number2;
    }
    public static bool isEven(int number1)
    {
        if(number1 % 2 == 0) 
        return true;
        return false;
    }

    public static bool isOdd(int number1)
    {
        if(number1 % 2 != 0)
        return true;
        return false;
    }

    public static bool isPrime(int number1)
    {
        int count = 0;
        for(int n=1; n <= number1; ++n)
        {
            if(number1 % n == 0)
            count += 1;
        }

        if(count == 2)
        return true;
        return false;
    }

    public static int countPrimes(int number1, int number2 )
    {
        int count = 0;
        for(int m= number1; m <= number2; ++ m)
        {
            if(isPrime(m) == true)
            count += 1;
        }
        return count;
    }

    public static int reverse(int number1)
    {
        int number = number1;
        int reverse = 0;
        int count = 0;
    
        while(number != 0)
        {
            int remainder = number % 10;
            reverse = reverse * 10 + remainder;
            number = number / 10;
            count += 1;
        }
        return reverse;
    }

    public  static int digitsCount(int number1)
    {
         int number = number1;
        int reverse = 0;
        int count = 0;
    
        while(number != 0)
        {
            int remainder = number % 10;
            reverse = reverse * 10 + remainder;
            number = number / 10;
            count += 1;
        }
        return count;
    }


} 