﻿using System;



    int a = int.Parse(args[0]);
    int b = int.Parse(args[1]);

    if(MathUtil.isEven(a) == true)
    Console.WriteLine($"{a} is Even");

     if(MathUtil.isOdd(a) == true)
    Console.WriteLine($"{a} is Odd");

     if(MathUtil.isPrime(a) == true)
    Console.WriteLine($"{a} is Prime");
    Console.WriteLine($"{a} is Non Prime" );

    Console.WriteLine("{0} Nos of Primes", MathUtil.countPrimes(a,b));

    Console.WriteLine("{0} is Reverse of {1}", MathUtil.reverse(a), a);

    Console.WriteLine("{0} Nos of digit", MathUtil.digitsCount(a));
   
