﻿namespace BannerLib;
class Program
{
    public static double BannerPrice(RegularBanner rb, int copies)
    {
        double rate = copies < 5 ? 0.8 : 0.75;
        return copies * rate * rb.Area();
    }

    public static void Main(string[] args)
    {
        double a = double.Parse(args[0]);
        double b = double.Parse(args[1]);
        double c = double.Parse(args[2]);
        int d = int.Parse(args[3]);

        RegularBanner regular = new RegularBanner(a ,b);
        var curved = new CurvedBanner(a,b,c);

        Console.WriteLine($"Price of Regular Banner is {BannerPrice(regular,d)}");
        Console.WriteLine($"Price of Curved Banner is {BannerPrice(curved, d)}");

    }
}
