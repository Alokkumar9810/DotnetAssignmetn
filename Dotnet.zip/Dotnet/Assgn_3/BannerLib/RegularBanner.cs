﻿namespace BannerLib;
public class RegularBanner
{
    private double width;
    private double height;

    public RegularBanner(double width, double height)
    {
        this.width = width;
        this.height = height;
    }
    public RegularBanner() : this( 20.10, 5.20 )
    {}

    public bool Resize(double w , double h)
    {
        if(w >= h)
        {
            width = w;
            height = h;
            return true;
        }
        return false;
    }
    public void Resize(float s)
    {
        Resize(s,s);
    }
    public virtual double Area()
    {
        return width * height;
    }
}
