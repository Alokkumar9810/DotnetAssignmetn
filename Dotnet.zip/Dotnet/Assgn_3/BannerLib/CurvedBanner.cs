namespace BannerLib;

public class CurvedBanner : RegularBanner
{
    private double radius;

    public CurvedBanner(double width, double height, double radius) : base(width,height)
    {
        this.radius = radius;
    }

    public override double Area()
    {
        return base.Area() - 0.86 * radius * radius ;
    }
}