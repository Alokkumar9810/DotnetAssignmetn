global using Microsoft.EntityFrameworkCore;

namespace DemoApp.HR;

public class HRDbContext : DbContext
{
    public DbSet<Employee> Employees {get; set;}

    public DbSet<Department> Departments {get; set;}

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseMySQL("Server=localhost;Database=employee;User ID=root;Password=root");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Employee>()
            .ToTable("emp")
            .Property(p => p.Id)
            .HasColumnName("eid");
        modelBuilder.Entity<Employee>()
            .Property(p => p.DepartmentId)
            .HasColumnName("dept_id");
        modelBuilder.Entity<Department>()
            .ToTable("department")
            .Property(p => p.Id)
            .HasColumnName("dept_id");
    }

}
