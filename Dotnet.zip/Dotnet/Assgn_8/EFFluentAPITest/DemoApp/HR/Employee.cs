namespace DemoApp.HR;

public class Employee
{
    public int Id { get; set; }

    public string ename { get; set; }

    public double salary { get; set; }

    public int age { get; set; }

    public int DepartmentId { get; set; }

    public double comm { get; set; }
}