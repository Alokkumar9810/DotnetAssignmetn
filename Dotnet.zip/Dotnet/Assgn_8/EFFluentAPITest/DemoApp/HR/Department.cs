namespace DemoApp.HR;

public class Department
{
    public int Id { get; set; }

    public string  d_name { get; set; }

    public string location { get; set; }

    public List<Employee> Employees { get; set; }
}