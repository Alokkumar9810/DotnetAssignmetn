﻿using DemoApp.HR;

var db = new HRDbContext();

if(args.Length == 0)
{
    foreach(var person in db.Employees)
        Console.WriteLine("{0, -6}{1, -10}{2, -10}{3, -10}{4, -12}", person.Id , person.ename, person.salary, person.age, person.DepartmentId);
}
else
{
    int dno = int.Parse(args[0]);
    var dept = db.Departments
            .Where(p => p.Id == dno)
            .Include(p => p.Employees)
            .FirstOrDefault();
    if(dept != null)
    {
        foreach(var detail in dept.Employees)
            Console.WriteLine("{0, -6}{1,10}",detail.Id, detail.ename );

    }
}