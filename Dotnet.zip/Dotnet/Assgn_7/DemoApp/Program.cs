using System.Runtime.CompilerServices;
class Program
{
public static void Main(string []args)
{
    var work = new Worker();
    int num = int.Parse(args[0]);
    Thread child = new Thread(() =>
        {
        work.Odd(num);
        }

    );

    child.Start();
    work.Even(num);

}

class Worker
{
    [MethodImpl(MethodImplOptions.Synchronized)]
   public  void Even(int number)
    {
        for(int n = 1; n <= number; ++n )

        if(n % 2 == 0)

        lock(typeof(Worker))
        {
        Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId} is printing Even :{n}");

        Monitor.Pulse(typeof(Worker));
        Monitor.Wait(typeof(Worker));

         }
    } 

     public  void Odd(int number)
    {
        for(int n = 1; n <= number; ++n )

        if(n % 2 != 0)

        lock(typeof(Worker))
        {
        Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId} is printing Odd  :{n}");

        Monitor.Wait(typeof(Worker));
        Monitor.Pulse(typeof(Worker));

         }
    } 
}
}
