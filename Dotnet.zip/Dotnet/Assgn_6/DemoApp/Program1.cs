﻿using Tours;
using System.Reflection;
using Charge = System.Func<int, int, double>;

class Program
{
    static void Main(string[] args)
    {
        int d = int.Parse(args[0]);
        int n = int.Parse(args[1]);
        Type t = Type.GetType(args[2]);
        MethodInfo scheme = t.GetMethod(args[3]);
        object tour = Activator.CreateInstance(t);
        Charge rate = scheme.CreateDelegate<Charge>(tour);
        double i = rate(d,n);
        Console.WriteLine("{0}",i);

        
    }
}