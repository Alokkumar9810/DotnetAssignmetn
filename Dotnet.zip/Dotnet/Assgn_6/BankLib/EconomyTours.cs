﻿namespace Tours;
[LuxuryTax]
public class EconomyTours 
{
 public double getDaysRent(int days, int noPerson) => 500 * days * noPerson;

}
                                                                                                        