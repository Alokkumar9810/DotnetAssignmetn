namespace Tours;

[AttributeUsage(AttributeTargets.Class)]

public class LuxuryTaxAttribute : Attribute
{
    public int  Tax{get; set; }

    public LuxuryTaxAttribute(int value = 8)
    {
        Tax = value;
    }
}