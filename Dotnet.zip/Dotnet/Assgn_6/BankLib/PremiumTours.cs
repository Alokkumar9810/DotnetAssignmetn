namespace Tours;
[LuxuryTax(Tax = 10)]
public class PremiumTours
{
    private double amount = 1200;

    public double getDaysRentForCommon(int days, int noPerson)   
    {
       if(days > 6)
       amount = amount -100;
       if(noPerson > 4)
       amount = amount - 100;
       return amount * days * noPerson;

    }
    public double getDaysRentForSenoirs(int days, int noPerson) => getDaysRentForCommon(days , noPerson) - 100 * days;

    public double getDaysRentForWoman(int days, int noPerson) => getDaysRentForCommon(days , noPerson) - 200 * days;
    
}