namespace BankLib;

public static class Banker
{
      
	
	public static Loan openHomeLoan(double p, float n){
		Loan hl1 = new HomeLoan(p,n);
		return hl1;
	}

	public static Loan openPersonalLoan(double p , float n){
		Loan Pl1 = new PersonalLoan(p,n);
		return Pl1;
	}
	
	
}
		