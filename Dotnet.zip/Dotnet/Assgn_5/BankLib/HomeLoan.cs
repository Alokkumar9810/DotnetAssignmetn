namespace BankLib;

sealed class HomeLoan : Loan, Discountable
{
   public HomeLoan(double principle, float period) : base(principle, period)
   {
    
   }

   public override float getRate()
   {
        return Principle > 2000000 ? 11 : 10;     
   }

   public double getDiscount()
   {
		double EMI = base.getEMI();
		return EMI *= 0.95;
    }
}