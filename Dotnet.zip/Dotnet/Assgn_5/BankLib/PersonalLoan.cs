namespace BankLib;

sealed  class PersonalLoan : Loan ,Taxable
{

    public PersonalLoan(double principle, float period) : base(principle,period)
	{

    }

    public override float getRate()
   {
        return Principle > 500000 ? 16 : 15;     
   }

    public double getTax()
   {
		double EMI = base.getEMI();
		return EMI *= 1.18;
    }

}