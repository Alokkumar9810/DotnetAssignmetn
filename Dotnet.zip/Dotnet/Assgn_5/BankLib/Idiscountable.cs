namespace BankLib;

public interface Discountable
{
    
	double getDiscount();
}
