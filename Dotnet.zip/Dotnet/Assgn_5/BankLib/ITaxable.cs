namespace BankLib;

public interface Taxable
{

	double getTax();

}
