﻿namespace BankLib;
public abstract class Loan
{
  private double principle;
  private float period;

  public Loan(double principle, float period)
  {
    this.principle = principle;
		this.period = period;
  }

  
  public double Principle
  {
    get
    {
        return principle;
    }
    set
    {
        principle = value;
    }
  }

  public float Period
  {
    get
    {
        return period;
    }
    set
    {
        period = value;
    }
  }

  public abstract float getRate();

  public double getEMI()
  {
    double rate = getRate();
    double first = principle * (1 + rate * period/100);
	double second = 12 * period ;
	double EMI = first/ second;
	return EMI;
  }
  
}

