﻿using BankLib;

class Program
{

	private static double getfinalHomeEmi(Loan temp){
		if(temp is Discountable d)
		       return d.getDiscount();
		return temp.getEMI();
	}	
	
	private static double getfinalPersonalEmi(Loan temp){
		if(temp is Taxable d)
		       return d.getTax();
		return temp.getEMI();
	}

	public static void Main(string []args){
		double p = double.Parse(args[0]);
		float n = float.Parse(args[1]);	
		
		Loan jack = Banker.openHomeLoan(p,n);
		Loan jill = Banker.openPersonalLoan(p,n);
		
		
		
		Console.WriteLine("jack Homeloan EMI :  {0:0.00} || EMI after Discount : {1:0.00}",jack.getEMI(), getfinalHomeEmi(jack));
		Console.WriteLine("jill Personalloan EMI : {0:0.00} || EMI after Taxable :  {1:0.00}" ,jill.getEMI(), getfinalPersonalEmi(jill));
}
}
