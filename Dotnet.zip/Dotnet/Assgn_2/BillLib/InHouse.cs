namespace BillLib;

public class InHouse : Patient
{
    public InHouse(int id , int type, int days, double disc) : base(id, type, days)
    {
        Discount = disc;
    }

    public InHouse() : this (101, 1, 5, 0.05)
    {
    
    }

    public double Discount { get; set; }

    public override double getBillAmount()
    {
        double amount = base.getBillAmount();
        Discount = amount > 5000 ? Discount : 0.05;
        return amount = amount * (1- Discount);

    }
}