﻿namespace BillLib;

public class Patient
{
    public Patient(int id , int type, int days)
    {
      PatientId = id;
      BedType = type;
      NoofDays = days;
    }

    public Patient() : this (101, 1, 5)
    {
        
    }
    public int PatientId { get; set; }

    public int BedType { get; set; }

    public int NoofDays { get; set; }

    public int getPricePerDay()
    {
         int type = BedType;
         int price = 0;

         switch (type)
         {
            case 1:
                    price = 500;
                break;
            case 2:
                    price = 350;
                break;
            case 3:
                    price = 200;
                break;
            default:
                    Console.WriteLine("Invalid Bed Type");
                break;
        
         }
         return price;
    }
    public virtual double getBillAmount()
    {
        double amount = 0;
        amount = NoofDays * getPricePerDay();
        return amount;
    }
}
