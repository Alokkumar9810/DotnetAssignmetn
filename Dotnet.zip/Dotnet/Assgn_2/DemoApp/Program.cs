﻿using BillLib;

class Bill
 {
	public static void Main (string []args){
	int i = int.Parse(args[0]);	
	int t = int.Parse(args[1]);	
	int d = int.Parse(args[2]);	
	double  di = double.Parse(args[3]);

	Patient p = new Patient(i, t,d);
	InHouse ip = new InHouse(i,t,d,di);

	Console.WriteLine("Total bill for Ordinary Patient: {0}",p.getBillAmount());
	Console.WriteLine("Total bill for InHouse Patient: {0}",ip.getBillAmount());
	}
}
