namespace SeriesLib;

public interface IResetable
{

void Reset();
}
