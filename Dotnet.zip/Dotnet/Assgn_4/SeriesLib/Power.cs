namespace SeriesLib;

sealed class Power : Sequence ,IResetable
{

	public int Factor { get; set; }

    public Power (int current, int factor) 
    {
		Current = current;
		Factor = factor;
    }
	public Power() : this(1,3)
    {

	}

	public override int Next()
    {
	int term = Current;
	Current *= Factor;
	return term;
	}

	public void Reset(){
	Current = 1;
	}
}
