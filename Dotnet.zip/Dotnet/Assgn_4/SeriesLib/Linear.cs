namespace SeriesLib;

sealed class Linear : Sequence 
{

	public int Step { get; set; }

    public Linear(int current, int step) 
    {
       Current = current;
	    Step = step;
    }

	public Linear() : this (7,5)
    {
	
	}

	public override int Next() {
	int term = Current;
	Current += Step;
	return term;
	}
}