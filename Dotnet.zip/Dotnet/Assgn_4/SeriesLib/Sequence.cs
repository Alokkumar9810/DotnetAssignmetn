﻿namespace SeriesLib;

public abstract class Sequence
{

	public int Current { get; set; }

	// public Sequence(intcurrent)
	// {
	// 	Current = current;
	// }

	// public Sequence() : this(7)
	// {
		
	// }
	
	public abstract int Next();

	public int  Sum(int count)
    {
	    int total = 0;
	   for (int i = 1;i<=count; ++i)
       {
		  total += Next(); 
	   }
	   	return total;
	}
	      
             
}