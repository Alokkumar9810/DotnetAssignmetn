namespace SeriesLib;

public static class calculation
{
     
     //public static Sequence linear(int  current ,int  step)
	public static Sequence linear(int  current, int  step)
    {
		
	Sequence seq1 = new Linear( current, step);
    //var seq1 = new Linear();
	return seq1;
	}
     //public static Sequence power(int  current ,int  factor)
	public static Sequence power(int  current, int  factor )
    {
		
		var seq2 = new Power(current , factor);
        //var seq2 = new Power();
		return seq2;
	}
	

}
