﻿using SeriesLib;

 class Program
 {

		 public static int  compute(Sequence seq, int count){
			 if(seq is IResetable r){
				 r.Reset();
			 }
			 return seq.Sum(count)/count;
		 }

	public static void Main(string[] args)
    {
        int  current = int.Parse(args[0]);
        int  step = int.Parse(args[1]);
        int  factor = int.Parse(args[2]);
        int count = int.Parse(args[3]);
        
        
		//Sequence seq1 = calculation.linear(current, step);
		//Sequence seq2 = calculation.power(current, factor);

		Sequence seq1 = calculation.linear(current, step);
		Sequence seq2 = calculation.power(current, factor);

		Console.WriteLine($"Linear sum 1 :{seq1.Sum(count):0.00}");
		Console.WriteLine($"Power sum  1  :{seq2.Sum(count):0.00}");
		
		Console.WriteLine($"Linear sum 2 :{seq1.Sum(count):0.00}");
		Console.WriteLine($"Power sum  2  :{seq2.Sum(count):0.00}");
		
		 Console.WriteLine("Linear Sequence Average: {0:0.00}",compute(seq1,count));
		 Console.WriteLine("Power Sequence Average: {0:0.00}",compute(seq2,count));
	

	}
}
